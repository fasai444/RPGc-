#ifndef GAME_HPP
#define GAME_HPP

#include "../Entities/Player.hpp"
#include "Combat.hpp"  // Make sure to include Combat.hpp if you're using Combat in this file

class Game {
private:
    bool running;
    Player player; // Ensure this is properly declared
    void initializePlayer(); // Declare initializePlayer

public:
    Game();
    Game(Player player);
    ~Game();

    void start();
    void run();
    void gameLoop(); // Declare gameLoop here
};

#endif // GAME_HPP
