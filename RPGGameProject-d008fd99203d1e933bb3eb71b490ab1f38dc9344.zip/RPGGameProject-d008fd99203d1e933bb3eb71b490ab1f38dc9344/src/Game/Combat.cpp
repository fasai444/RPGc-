#include "Combat.hpp"
#include "../Utils/StringUtils.hpp"
#include "../Utils/Utils.hpp"
#include "../Utils/EnhancedUI.hpp"  // Adjust the path based on your directory structure
#include "UI.hpp"
#include <chrono>
#include <thread>
#include <iostream>
#include <algorithm>
#include <cctype>

// Constructeur par défaut
Combat::Combat() : player(*(new Player())), enemy(Enemy()) {
    this->inCombat = false; // Le combat n'est pas en cours par défaut
}

// Constructeur avec paramètres
Combat::Combat(Player &player, Enemy enemy) : player(player), enemy(enemy) {
    this->inCombat = enemy.getHP() > 0; // Vérifie si l'ennemi a des points de vie pour commencer le combat

    // Ajoute des objets à l'inventaire du joueur si non déjà présents
    if (!player.getInventory().getItem("Épée en fer")) {
        player.getInventory().addItem(Item("Épée en fer", "Weapon", 50)); // Arme de base
    }
    if (!player.getInventory().getItem("Potion de vie")) {
        player.getInventory().addItem(Item("Potion de vie", "Potion", 100)); // Potion de soin
    }
}

// Destructeur
Combat::~Combat() {}

// Affiche l'interface de combat
void displayCombatUI(const Player& player, const Enemy& enemy) {
    UI::printCombatMenu(player, enemy);
}

// Boucle principale du combat
void Combat::insideCombat() {
    while (!player.isDead() && !enemy.isDead()) {
        EnhancedUI::displayCombatScreen(player, enemy);

        int choice;
        Utils::validateInput(choice, "Choose your action: ");

        switch (choice) {
            case 1: {  // Player attacks
                int damage = player.getAttack();
                enemy.setHP(enemy.getHP() - damage);
                std::cout << Color::GREEN << "You attack and deal " << damage << " damage!\n" << Color::RESET;
                break;
            }
            case 2: {  // Flee
                std::cout << Color::YELLOW << "You flee from combat!\n" << Color::RESET;
                return;
            }
            default:
                std::cout << Color::RED << "Invalid choice.\n" << Color::RESET;
                continue;
        }

        // Enemy uses ability
        if (!enemy.isDead()) {
            if (enemy.getAbility() == "Poison") {
                int poisonDamage = 5;
                player.setHP(player.getHP() - poisonDamage);
                std::cout << Color::RED << enemy.getName() << " uses Poison! You take "
                          << poisonDamage << " damage over time.\n" << Color::RESET;
            } else if (enemy.getAbility() == "Stun") {
                bool isStunned = Utils::getRandomNumber(0, 1);  // 50% chance
                if (isStunned) {
                    std::cout << Color::RED << enemy.getName() << " uses Stun! You are stunned and lose your next turn.\n" << Color::RESET;
                    std::this_thread::sleep_for(std::chrono::seconds(2));  // Pause for 2 seconds
                    continue;
                }
            } else if (enemy.getAbility() == "Web Trap") {
                int attackReduction = 3;
                player.setAttack(player.getAttack() - attackReduction);
                std::cout << Color::RED << enemy.getName() << " uses Web Trap! Your attack is reduced by "
                          << attackReduction << " for the next 2 turns.\n" << Color::RESET;
                std::this_thread::sleep_for(std::chrono::seconds(2));  // Pause for 2 seconds
            }

            // Enemy's basic attack
            int damage = enemy.getAttack();
            player.setHP(player.getHP() - damage);
            std::cout << Color::RED << enemy.getName() << " attacks and deals "
                      << damage << " damage!\n" << Color::RESET;
        }
    }

    if (player.getHP() > 0) {
        std::cout << Color::GREEN << "You defeated the enemy!\n" << Color::RESET;
    } else {
        std::cout << Color::RED << "You were defeated...\n" << Color::RESET;
    }
}


// Vérifie si l'ennemi est vaincu
bool Combat::isEnemyDefeated() const {
    return enemy.getHP() <= 0;
}
