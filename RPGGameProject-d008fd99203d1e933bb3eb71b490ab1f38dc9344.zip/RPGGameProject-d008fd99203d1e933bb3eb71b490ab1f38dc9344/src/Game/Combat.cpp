// Combat.cpp
#include "Combat.hpp"
#include <iostream>
#include "../Utils/Utils.hpp"

Combat::Combat() {
    this->inCombat = false;
}

Combat::Combat(Player player, Enemy enemy) {
    this->player = player;
    this->enemy = enemy;
    this->inCombat = enemy.getHP() > 0 || enemy.getHP() > 0;

    // Adding items to player's inventory at the start of combat
    player.getInventory().addItem(Item("Épée en fer", "Weapon", 50));  // Weapon dealing 50 damage
    player.getInventory().addItem(Item("Potion de vie", "Potion", 100));  // Potion that heals 100 HP
}

Combat::~Combat() {}

void Combat::insideCombat() {
    while (!player.isDead() && !enemy.isDead()) {
        int choice;
        std::cout << "Tour de " << player.getName() << "\n";
        std::cout << "HP du " << enemy.getName() << " : " << enemy.getHP() << "\n";

        std::cout << "1. Attaquer\n";
        std::cout << "2. Fuir\n";
        std::cout << "3. Utiliser un objet\n";  // New option to use an item
        Utils::validateInput(choice, "Que voulez-vous faire ? :");

        switch (choice) {
            case 1: {
                // Player attack logic
                int damage = player.getAttack();
                enemy.setHP(enemy.getHP() - damage);
                std::cout << "Vous attaquez et infligez " << damage << " points de dégâts !" << std::endl;
                std::cout << "Le " << enemy.getName() << " a maintenant " << enemy.getHP() << " HP." << std::endl;
                break;
            }
            case 2: {
                // Player flee logic
                std::cout << "Vous fuyez le combat !" << std::endl;
                return;
            }
            case 3: {
                // Use an item
                if (!player.getInventory().isEmpty()) {
                    player.getInventory().showInventory();  // Show available items
                    std::string itemName;
                    std::cout << "Entrez le nom de l'objet à utiliser : ";
                    std::cin >> itemName;

                    Item* item = player.getInventory().getItem(itemName);  // Retrieve item from inventory
                    if (item) {
                        if (item->getType() == "Potion") {
                            // Potion logic: heal player
                            player.setHP(player.getHP() + item->getEffect());
                            std::cout << "Vous utilisez " << item->getName() << " et récupérez " << item->getEffect() << " HP.\n";
                            player.getInventory().removeItem(itemName);  // Remove the used item
                        } else if (item->getType() == "Weapon") {
                            // Weapon logic: inflict damage on the enemy
                            int damage = item->getEffect();  // Get weapon's damage value
                            enemy.setHP(enemy.getHP() - damage);
                            std::cout << "Vous utilisez " << item->getName() << " et infligez " << damage << " points de dégâts au " << enemy.getName() << " !\n";
                            std::cout << "Le " << enemy.getName() << " a maintenant " << enemy.getHP() << " HP.\n";
                            player.getInventory().removeItem(itemName);  // Remove the used item
                        } else {
                            std::cout << "Cet objet n'est pas utilisable.\n";
                        }
                    } else {
                        std::cout << "Cet objet n'existe pas dans votre inventaire.\n";
                    }
                } else {
                    std::cout << "Votre inventaire est vide.\n";
                }
                break;
            }
            default: {
                std::cout << "Choix invalide.\n";
                break;
            }
        }

        // Enemy attack logic
        if (!enemy.isDead()) {
            int damage = enemy.getAttack();
            player.setHP(player.getHP() - damage);
            std::cout << "Le " << enemy.getName() << " vous attaque et inflige " << damage << " points de dégâts !" << std::endl;
            std::cout << "Il vous reste " << player.getHP() << " HP." << std::endl;
        }
    }
}

bool Combat::isEnemyDefeated() const {
    return enemy.getHP() <= 0;  // Check if the enemy's HP is 0 or below
}
