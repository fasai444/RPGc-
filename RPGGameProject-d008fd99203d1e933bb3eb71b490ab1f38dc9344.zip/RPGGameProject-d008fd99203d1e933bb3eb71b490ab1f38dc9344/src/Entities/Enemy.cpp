#include "Enemy.hpp"
#include "../Utils/Utils.hpp"

Enemy::Enemy() : Entity("", 0, 0, 0), ability("") {}

Enemy::Enemy(std::string name, int HP, int attack, int defense, std::string ability)
        : Entity(name, HP, attack, defense), ability(std::move(ability)) {}

std::string Enemy::getAbility() const {
    return ability;
}

Enemy Enemy::generateEnemy(int level) {
    int hp = 0, attack = 0, defense = 0;
    std::string ability;

    switch (level) {
        case 1:
            hp = 300;
            attack = 10;
            defense = 5;
            ability = "Poison";  // Deals poison damage over time
            break;
        case 2:
            hp = 500;
            attack = 15;
            defense = 10;
            ability = "Stun";  // Can skip player's turn
            break;
        case 3:
            hp = 700;
            attack = 20;
            defense = 15;
            ability = "Web Trap";  // Reduces player's attack temporarily
            break;
        default:
            hp = 300;
            attack = 10;
            defense = 5;
            ability = "None";
    }

    return Enemy("Enemy Level " + std::to_string(level), hp, attack, defense, ability);
}
