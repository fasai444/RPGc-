#include "Entity.hpp"

// Default constructor
Entity::Entity() {
    this->name = "";
    this->HP = 0;
    this->attack = 0;
    this->defense = 0;
}

// Constructor with name
Entity::Entity(std::string name) {
    this->name = name;
    Entity::setStats();
}

// Constructor with all parameters
Entity::Entity(std::string name, int HP, int attack, int defense) {
    this->name = name;
    this->HP = HP;
    this->attack = attack;
    this->defense = defense;
}

// Set default stats
void Entity::setStats() {
    this->HP = 0;
    this->attack = 0;
    this->defense = 0;
}

// Getter for name, marked as const
std::string Entity::getName() const {
    return name;
}

// Setter for name
void Entity::setName(std::string name) {
    this->name = name;
}

// Getter for HP, already marked as const
int Entity::getHP() const {
    return this->HP;
}

// Setter for HP
void Entity::setHP(int HP) {
    this->HP = HP;
}

// Getter for attack, now marked as const
int Entity::getAttack() const {
    return this->attack;
}

// Getter for defense, now marked as const
int Entity::getDefense() const {
    return this->defense;
}
